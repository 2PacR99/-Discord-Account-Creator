from .sessions import Session
from .sessions import Session as HttpClient
from .api import get, options, head, post, put, patch, delete
from . import exceptions
from . import structures